# -*- coding: utf-8 -*-
"""
Created on Tue Apr 20 17:39:36 2021

@author: julien
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from scipy.integrate import solve_ivp

#---------------------------------------
## Circuit RLC
#---------------------------------------

#Fonctions
def RLC_prim(Y,t) :
    C = 1e-6 #C = 1e-4  
    R = 3 
    L = 0.5 
    e = 10
    return np.array([(1/L)*(e-Y[1]-R*Y[0]),(1/C)*Y[0]])

def RLC_prim_ivp(t,Y) :
    C = 1e-6 #C = 1e-4
    R = 3 
    L = 0.5 
    e = 10
    return np.array([(1/L)*(e-Y[1]-R*Y[0]),(1/C)*Y[0]])


#---------------------------------------
#Méthodes
def solv_edo(t) :
    Yode = odeint(RLC_prim, Y0,t)
    return Yode

def solv_ivp(t) :
    Yode = solve_ivp(RLC_prim_ivp, [0,2], [0,0], t_eval=t) #, method='RK23'
    return Yode

def RK4(f,t,Y0,N,h) :
    Yrk = np.zeros((N,Y0.size))
    Yrk[0,:]=Y0.reshape(2)
    for k in range (N-1) :
        k1 = f(k*h,Yrk[k,:])
        k2 = f(k*h+(h/2),Yrk[k,:]+(h/2)*k1)
        k3 = f(k*h+(h/2),Yrk[k,:]+(h/2)*k2)
        k4 = f(k*h+h,Yrk[k,:]+h*k3)
        Yrk[k+1,:] = Yrk[k,:] + (h/6)*(k1+2*k2+2*k3+k4)
    return (Yrk)

#---------------------------------------
#Vecteur temps
a = 0
b = 2
N = 201
t = np.linspace(a,b,N)   
Y0 = np.array([0,0])  
h = (b-a)/N

#---------------------------------------
#Résolutions 
Yrk = RK4(RLC_prim_ivp,t,Y0,N,h)
Yedo=solv_edo(t)
Yivp=solv_ivp(t)

#---------------------------------------
#Tracés
#Intensité du circuit
plt.figure(1)
plt.plot(t,Yrk[:,0],label='Runge Kutta')
plt.plot(t,Yedo[:,0],label='Odeint')
plt.plot(t,Yivp.y[0,:],label='ivp')
plt.title("Intensité du système RLC") 
plt.xlabel('Temps (s)')
plt.ylabel('Intensité i(t) (V)')
plt.grid(True)
plt.legend()
plt.show()

#Tension du circuit
plt.figure(2)
Yrk = RK4(RLC_prim_ivp,t,Y0,N,h)
Yode=solv_edo(t)
plt.plot(t,Yrk[:,1],label='Runge Kutta')
plt.plot(t,Yode[:,1],label='Odeint')
plt.plot(t,Yivp.y[1,:],label='ivp')
plt.title("Tension du système RLC") 
plt.xlabel('Temps (s)')
plt.ylabel('Tension s(t) (A)')
plt.grid(True)
plt.legend()
plt.show()