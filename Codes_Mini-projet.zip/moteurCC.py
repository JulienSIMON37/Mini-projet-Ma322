# -*- coding: utf-8 -*-
"""
Created on Fri Apr 21 20:01:53 2021

@author: julien
"""
import numpy as np
from matplotlib import pyplot as plt
from scipy.integrate import odeint

#---------------------------------------
## Moteur à courant continue
#---------------------------------------

#Données
R = 5
L = 50*10**(-3)
Ke = 0.2
Kc = 0.1
Fm = 0.01
Jm = 0.05

#---------------------------------------
#Fonction échelon de tension
def Ut(t) : 
    if (t<10 or t>50) :
        return 0
    else:
        return 5
    
#---------------------------------------
#Création vecteur tension
liste_U = list()

#---------------------------------------
#Initialisation
a = 0
b = 80
N = 8000
Y0 = [0,0]
t = np.linspace(a,b,N)

for i in t :
    liste_U.append(Ut(i))

#---------------------------------------
#Fonction
def moteurCC(Y,t) :
    return np.array([(1/L)*(Ut(t)-R*Y[0]-Ke*Y[1]),(1/Jm)*(Kc*Y[0]-Fm*Y[1])])

#---------------------------------------
#Résolution de l'equation intégrale
Yode = odeint(moteurCC,Y0,t)

#---------------------------------------
#Couple moteur
Cm = Kc*Yode[:,0]

#---------------------------------------
#Tracés
#Vitesse angulaire
plt.plot(t,Yode[:,1],'y',label="Odeint")
plt.title("Evolution de la vitesse angulaire")
plt.xlabel("Temps (s)")
plt.ylabel("w(t) en rad/s")
plt.legend()
plt.grid()
plt.show()

#Couple moteur
plt.plot(t,Cm,'g',label="Odeint")
plt.title("Evolution du couple moteur")
plt.xlabel("Temps (s)")
plt.ylabel("Cm(t) en N.m")
plt.legend()
plt.grid()
plt.show()

#Tension
plt.plot(t,liste_U,'b',label="Tension")
plt.title("Evolution de la tension")
plt.xlabel("Temps (s)")
plt.ylabel("u(t) (V)")
plt.legend()
plt.grid()
plt.show()
