# -*- coding: utf-8 -*-
"""
Created on Fri Apr 21 20:44:50 2021

@author: julien
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint

#---------------------------------------
## Mouvement d'une fusée
#---------------------------------------

#Fonction
def fusee(Y,t) :
    #Données
    D = 4
    a = 8*10**3
    g = 9.81
    k = 0.1
    u = 2*10**3
    
    #Construction du vecteur Y
    Yprime = np.zeros(3)
    if (Y[1] < 80) :
        Y[1] = 80
        D = 0
    
    Yprime[0] = D*u/Y[1] -g -k*np.exp(-Y[2]/a)*Y[0]**2/Y[1]
    Yprime[1] = -D
    Yprime[2] = Y[0]
    
    return Yprime

#---------------------------------------
#Vecteur temps
a = 0
b = 160
N = 100
Y0 = [0,0]
t = np.linspace(a,b,N)

#---------------------------------------
#Résolution de l'equation intégrale
Y0 = [0,400,0]
Y = odeint(fusee, Y0, t)

#---------------------------------------
#Tracés
#Vitesse de la fusée
plt.plot(t,Y[:,0],label="Vitesse de la fusée")
plt.xlabel("Temps (s)")
plt.ylabel("Vitesse v (m/s)")
plt.legend()
plt.grid()
plt.show()

#Trajectoire de la fusée
plt.plot(t,Y[:,2],label="Trajectoire de la fusée")
plt.xlabel("Temps (s)")
plt.ylabel("Hauteur (m)")
plt.legend()
plt.grid()
plt.show()