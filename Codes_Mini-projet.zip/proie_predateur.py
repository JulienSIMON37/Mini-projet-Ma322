# -*- coding: utf-8 -*-
"""
Created on Sat Apr 22 11:09:05 2021

@author: julien
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint

#---------------------------------------
## Modèle proie-prédateur
#---------------------------------------

#Fonctions
#Proies
def proies () :
    alpha1 = 3
    L1 = list()
    for i in range (0,10):
        if i == 0 :
            L1.append(5)
        else:
            L1.append(L1[i-1]*alpha1)
    return L1

#Prédateurs
def predateurs () :
    alpha2 = -2
    L2 = list()
    for i in range (0,10) :
        if i == 0:
            L2.append(3)
        else:
            if L2[i-1]<0 :
                L2.append(L2[i-1]*-alpha2)
            else: 
                L2.append(L2[i-1]*alpha2)
    return L2

#Proie-prédateurs
def proie_predateur(Y,t):
    alpha1 = 3
    beta1 = 1
    alpha2 = 2
    beta2 = 1
    
    return np.array([alpha1*Y[0]-beta1*Y[0]*Y[1],-alpha2*Y[1]+beta2*Y[0]*Y[1]])

#---------------------------------------
#Méthodes
def Euler_explicit(proie_predateur,Y0,N,h) :
    Ye = np.zeros((N,Y0.size))
    Ye[0,:] = Y0
    
    for k in range(N-1) :
        Ye[k+1,:] = Ye[k,:] + h*proie_predateur(Ye[k,:],t[k])
    return Ye

def solv_edo(t) :
    return odeint(proie_predateur,Y0,t)

#---------------------------------------
#Vecteur temps
a = 0
b = 10
N = 101
t = np.linspace(a,b,N)   
Y0 = np.array([5,3])  
h = (b-a)/N

#---------------------------------------
#Résolution sans prédateur 
Lievre = proies()

#Résolution sans proie
Lynx = predateurs()

#Résolution de l'equation intégrale
Ye = Euler_explicit(proie_predateur,Y0,N,h)
# Yrk= RK4(proie_predateur,t,Y0,N,h)
Yode = solv_edo(t)
Tpp = np.linspace(0,10,10)

#---------------------------------------
#Tracés
#Proies sans prédateurs
plt.figure(figsize=(10,5))
plt.plot(Tpp,Lievre,label="proies",color="red")
plt.xlabel("Nombre d'années")
plt.ylabel("Nombre de spécimen")
plt.legend(loc=1)
plt.grid(True)
plt.title("Evolution du nombre de proies en fonction du temps sans prédateur")
plt.show()

#Prédateurs sans proie
plt.figure(figsize=(10,5))
plt.plot(Tpp,Lynx,label="predateurs",color="black")
plt.xlabel("Nombre d'années")
plt.ylabel("Nombre de spécimen")
plt.legend(loc=1)
plt.grid(True)
plt.title("Evolution du nombre de prédateurs en fonction du temps sans proie")
plt.show()

#Evolution proies-prédateur avec la méthode d'Euler
plt.figure(figsize=(10,5))
plt.plot(t,Ye[:,0], label="proies",color="red")
plt.plot(t,Ye[:,1], label="prédateurs",color="black")
plt.xlabel("Nombre d'années")
plt.ylabel("Nombre d'especes")
plt.grid(True)
plt.legend(loc=1)
plt.title("Evolution du nombre de prédateurs en fonction du temps (Euler)")
plt.show()

#Evolution proies-prédateur avec la méthode du solveur odeint
plt.figure(figsize=(10,5))
plt.plot(t,Yode[:,0], label="proies",color="red")
plt.plot(t,Yode[:,1], label="prédateurs",color="black")
plt.xlabel("Nombre d'années")
plt.ylabel("Nombre d'especes")
plt.grid(True)
plt.legend(loc=1)
plt.title("Evolution du nombre de prédateurs en fonction du temps")
plt.show()

#Portait de phase Euler
plt.figure(figsize=(10,5))
plt.plot(Ye[:,0],Ye[:,1], label="Odeint",color="blue")
plt.xlabel("Proies")
plt.ylabel("Prédateurs")
plt.grid(True)
plt.legend(loc=1)
plt.title("Portrait de phase (Euleur)")
plt.show()

#Portait de phase odeint
plt.figure(figsize=(10,5))
plt.plot(Yode[:,0],Yode[:,1], label="Odeint",color="blue")
plt.xlabel("Proies")
plt.ylabel("Prédateurs")
plt.grid(True)
plt.legend(loc=1)
plt.title("Portrait de phase (odeint)")
plt.show()
